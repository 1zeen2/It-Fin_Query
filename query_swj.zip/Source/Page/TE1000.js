
TE1000 = class TE1000 extends AView
{
	constructor()
	{
		super()

		// this.contiKey = '';
        this.queryList = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		this.createCkEditor(this.noticeContent.element);
	}

	onInitDone()
	{
		super.onInitDone()

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

	}

    createCkEditor(target)
    {
        return ClassicEditor.create(target, {
            language: 'ko',
            extraPlugins: [customUploadAdapterPlugin],
        })
        .then(editor => {
            editor.editing.view.change(writer => writer.setStyle('height', '200px', editor.editing.view.document.getRoot()))
            this.noticeContent = editor;
        })
        .catch(console.error);

        function customUploadAdapterPlugin(editor) {
            editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
                return new UploadAdapter(loader, `${config.SERVER_ADDRESS}:${config.SERVER_PORT}/upload`);
            };
        }
    }

    // 라디오버튼 값 가져오기 => 공지 목록 출력 시 사용
    // CRUD할 때는 SelectBox 사용
    radioGroupFunc() { 
        return this.radioGroup.getSelectValue();
    }

    /**
     *  조회 및 더보기 로직
     *  조회는 화살표 함수로 렉시컬 스코프를 활용해
     *  queryList를 초기화 할 때 this.로 접근했하였음.
     *  
     *  더보기 로직은 function()을 사용하고 const thisObj = this;를 활용할 예정
     *    ==> 유튜브 영상에는 function()을 사용했었음
     * 
     *  bind(this)는 무거워지고 화살표 함수로 대체가 가능하다고 해서 사용하지 않을 예정.
     */
	onInquiryButtonClick(comp, info, e)
	{

        const radioGroupValue = this.radioGroupFunc();

        if (radioGroupValue === null) {
            return AToast.show('조회 유형을 선택해주세요.');
        }

        const startDate = this.startDate.getDateString();
        const endDate = this.endDate.getDateString();

        theApp.qm.sendProcessByName('TE1000', this.getContainerId(), null,
        (queryData) => {
            const inblock1 = queryData.getBlockData('InBlock1')[0];
            inblock1.notice_type = radioGroupValue;
            inblock1.start_date = startDate;
            inblock1.end_date = endDate;
            inblock1.next_key = '';
            
        },
        (queryData) => {  
            const outblock1 = queryData.getBlockData('OutBlock1');

            this.queryList.removeAll();

            if (outblock1.length > 0) {
                this.contiKey = outblock1[outblock1.length - 1].next_key;
            }

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회할 데이터가 없습니다.');
                return;
            }
        });
	}

    // 더보기 로직
	onNextButtonClick(comp, info, e)
	{

		const thisObj = this;
        const radioGroupValue = this.radioGroupFunc();

        if (radioGroupValue === null) {
            return AToast.show('조회 유형을 선택해주세요.');
        }

        console.log("선택된 값:", radioGroupValue);

        const startDate = this.startDate.getDateString();
        const endDate = this.endDate.getDateString();


        theApp.qm.sendProcessByName('TE1000', this.getContainerId(), null,
        function(queryData) {
            const inblock1 = queryData.getBlockData('InBlock1')[0];
            inblock1.notice_type = radioGroupValue;
            inblock1.start_date = startDate;
            inblock1.end_date = endDate;
            inblock1.next_key = thisObj.contiKey;

            console.log('인블럭1값임: ', inblock1);
            
        },
        function(queryData) {  
            const outblock1 = queryData.getBlockData('OutBlock1');
            console.log('아웃블럭1값임: ', outblock1);

            if (outblock1.length > 0) {
                thisObj.contiKey = outblock1[outblock1.length - 1].next_key;
            }
            

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }
        });

	}

    // 공지 추가 로직
	onNoticeAddButtonClick(comp, info, e)
	{
        // 유효성 검사가 너무 길어질 수 있어 변수 만들어서 담음.
        const title = this.noticeTitleText.getText();
        const content = this.noticeContent.getData();
        const type = this.noticeTypeSelect.getData();

        if ( !title || !content || !type ) return AToast.show('모든 항목을 입력해주세요');
    
        theApp.qm.sendProcessByName('TE1011', this.getContainerId(), null,
            function(queryData)
            { // InBlock 설정
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                inblock1.notice_title = title
                inblock1.notice_content = content;
                inblock1.notice_type = type;
            },
            function(queryData)
        { // OutBlock 처리
        
            const errorData = this.getLastError();
            if (errorData.errFlag == "E") {
                console.log("Error Data:", errorData);
                AToast.show('에러가 발생했습니다.');
                return;
            }
            
            const outblock1 = queryData.getBlockData('OutBlock1');

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }

            if ( outblock1[0].success_status !== 'Y' ) {
                AToast.show('알림 등록에 실패했습니다.');
                return;
            }
        });
	}

    // 공지 상세 보기 로직
	onQueryListSelect(comp, info, e)
	{
        console.log('Grid의 row 선택 시 호출되는 콘솔: ', info);    // jQuery 객체로 받음. 
        const thisObj = this;
        const targetId = info[0].cells[0].innerText.trim();

        this.noticeIdText.setReadOnly(true);
        
        theApp.qm.sendProcessByName('TE1010', this.getContainerId(), null,
            function(queryData)
            { // InBlock 설정
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                inblock1.notice_id = Number(targetId);

            },
            function(queryData)
        { // OutBlock 처리            
            const outblock1 = queryData.getBlockData('OutBlock1');
            
            const data = outblock1[0];
            thisObj.noticeTypeSelect.selectItemByValue(String(data.notice_type));
            thisObj.noticeContent.setData(data.notice_content);

            console.log('쿼리 리스트 아웃블럭 값임: ', outblock1);
        });
	}

    // 공지 수정 로직
	onNoticeEditButtonClick(comp, info, e)
	{
            const thisObj = this;
            const id        = this.noticeIdText.getText();
            const title     = this.noticeTitleText.getText();
            const content   = this.noticeContent.getData();
            const type      = this.noticeTypeSelect.getData();

        if ( !id || !title || !content || !type ) return AToast.show('모든 항목을 입력해주세요');
    
        theApp.qm.sendProcessByName('TE1012', this.getContainerId(), null,
            function(queryData)
            { // InBlock 설정
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                inblock1.notice_id      = Number(id);
                inblock1.notice_title   = title;
                inblock1.notice_content = content;
                inblock1.notice_type    = type;

                console.log('인블럭1값임: ', inblock1);
            },
            function(queryData)
        { // OutBlock 처리
        
            const errorData = this.getLastError();
            if (errorData.errFlag == "E") {
                console.log("Error Data:", errorData);
                AToast.show('에러가 발생했습니다.');
                return;
            }
            
            const outblock1 = queryData.getBlockData('OutBlock1')[0];
            thisObj.onInquiryButtonClick();

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }

            if ( outblock1.success_status !== 'Y' ) {
                AToast.show('알림 등록에 실패했습니다.');
                return;
            }
        });

	}

    // 공지 삭제 로직
	onNoticeDeleteButtonClick(comp, info, e)
	{

		const noticeId = this.noticeIdText.getText();

        if ( !noticeId ) return AToast.show('삭제될 공지가 선택되지 않았습니다.');
    
        theApp.qm.sendProcessByName('TE1013', this.getContainerId(), null,
            function(queryData)
            { // InBlock 설정
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                inblock1.notice_id = Number(noticeId);

                console.log('인블럭1값임: ', inblock1);
            },
            function(queryData)
        { // OutBlock 처리
        
            const errorData = this.getLastError();
            if (errorData.errFlag == "E") {
                console.log("Error Data:", errorData);
                AToast.show('에러가 발생했습니다.');
                return;
            }
            
            const outblock1 = queryData.getBlockData('OutBlock1');

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }

            if ( outblock1[0].success_status !== 'Y' ) {
                AToast.show('알림 등록에 실패했습니다.');
                return;
            }

            console.log(outblock1[0]);
        });

	}

	onQueryListScrollbottom(comp, info, e)
	{

        if (!this.contiKey) {
            AToast.show('마지막 목록입니다.');
        }

        this.onNextButtonClick();

	}
}