
PnlHistory = class PnlHistory extends AView
{
	constructor()
	{
		super()

        this.tradeList = '';
        this.tradeListContiKey = '';

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    tradeTypeGroupFunc() { 
        return this.tradeTypeGroup.getSelectValue();
    }


	onTradeListViewButtonClick(comp, info, e)
	{

		const thisObj = this;
        const tabViewData = this.getContainer().getData();

        const parent = tabViewData.parent;
        
        const acntCd = parent.currentAcntCd;
        const startDate = parent.startDate.getDateString().replace(/-/g, ''); 
        const endDate = parent.endDate.getDateString().replace(/-/g, '');

        // 2. 통신 로직 실행
        theApp.qm.sendProcessByName('TE3020', this.getContainerId(), null,
            (queryData) => { 
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                if (inblock1) {
                    inblock1.acnt_cd = acntCd;
                    inblock1.start_date = startDate;
                    inblock1.end_date = endDate;
                    inblock1.next_key = '';
                }
                console.log('inBlock1 값: ', inblock1);
            },
            (queryData) => { 
                const outblock1 = queryData.getBlockData('OutBlock1');
                if (!outblock1 || outblock1.length === 0) return AToast.show('데이터가 없습니다.');

                thisObj.tradeList.removeAll();

                this.tradeListContiKey = outblock1[outblock1.length - 1].next_key;
                console.log('outBlock1 값: ', outblock1);
            }
        );

	}

	onTradeListViewNextButtondClick(comp, info, e)
	{

		const thisObj = this;
		const tabViewData = this.getContainer().getData();

        const parent = tabViewData.parent;
        
        const acntCd = parent.currentAcntCd;
        const startDate = parent.startDate.getDateString().replace(/-/g, ''); 
        const endDate = parent.endDate.getDateString().replace(/-/g, '');
        
        theApp.qm.sendProcessByName('TE3020', this.getContainerId(), null,
            (queryData) => { // InBlock 설정
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                inblock1.acnt_cd = acntCd;
                inblock1.start_date = startDate;
                inblock1.end_date = endDate;
                inblock1.next_key = thisObj.tradeListContiKey;

                console.log('쿼리 리스트 셀렉트 인블럭1 값임: ', inblock1);
            },
            (queryData) => { // OutBlock 처리

            const outblock1 = queryData.getBlockData('OutBlock1');

            if (!outblock1 || outblock1.length === 0) {
                return AToast.show('거래 내역이 없습니다.');
            }

            thisObj.tradeListContiKey = outblock1[outblock1.length - 1].next_key;

            console.log('쿼리 리스트 아웃블럭 값임: ', outblock1);

        });


	}

	onOrderHistoryClick(comp, info, e)
	{

		this.owner.selectTabById('OrderHistory');

	}

    onActivityLogClick(comp, info, e)
	{

		this.owner.selectTabById('ActivityLog');

	}

	onPnlHistoryClick(comp, info, e)
	{

		this.owner.selectTabById('PnlHistory');

	}

	onTransferHistoryClick(comp, info, e)
	{

		this.owner.selectTabById('TransferHistory');

	}
}

