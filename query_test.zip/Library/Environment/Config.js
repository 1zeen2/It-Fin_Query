const config = {
    SERVER_ADDRESS  : 'http://172.30.1.82',
    SERVER_PORT     : '5010',
    SERVER_PATH     : 'api',
};
Object.freeze(config);
