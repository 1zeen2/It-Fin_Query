const menuCollection = {
    TE1000: '메인',
    TE2000: '서브1',
};
Object.freeze(menuCollection);
