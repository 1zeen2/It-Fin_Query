
TE1000 = class TE1000 extends AView
{
	constructor()
	{
		super()

		this.contiKey = '';
        this.startDate = null;
        this.endDate = null;
        this.queryList = null;
        this.noticeTypeSelect = null;
        this.noticeTitleText = null;
        this.noticeIdText = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		this.createCkEditor(this.noticeContent.element);
	}

	onInitDone()
	{
		super.onInitDone()

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

	}

    createCkEditor(target)
    {
        return ClassicEditor.create(target, {
            language: 'ko',
            extraPlugins: [customUploadAdapterPlugin],
        })
        .then(editor => {
            editor.editing.view.change(writer => writer.setStyle('height', '200px', editor.editing.view.document.getRoot()))
            this.noticeContent = editor;
        })
        .catch(console.error);

        function customUploadAdapterPlugin(editor) {
            editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
                return new UploadAdapter(loader, `${config.SERVER_ADDRESS}:${config.SERVER_PORT}/upload`);
            };
        }
    }

    // 라디오버튼 값 가져오기
    radioGroupFunc() { 
        return this.radioGroup.getSelectValue();
    }

    /**
     *  조회 로직
     */
	onInquiryButtonClick(comp, info, e)
	{
        const thisObj = this;
        const radioGroupValue = this.radioGroupFunc();

        if (radioGroupValue === null) {
            return AToast.show('조회 유형을 선택해주세요.');
        }

        console.log("선택된 값:", radioGroupValue); // '0', '1', '2' 등 출력

        const startDate = this.startDate.getDateString();
        const endDate = this.endDate.getDateString();


        theApp.qm.sendProcessByName('TE1000', this.getContainerId(), null,
        function(queryData) {
            const inblock1 = queryData.getBlockData('InBlock1')[0];
            inblock1.notice_type = radioGroupValue;
            inblock1.start_date = startDate;
            inblock1.end_date = endDate;
            inblock1.next_key = this.contiKey;

            console.log('인블럭1값임: ', inblock1);
            
        },
        function(queryData) {  

            const outblock1 = queryData.getBlockData('OutBlock1');
            console.log('아웃블럭1값임: ', outblock1);

            if (outblock1.length > 0) {
                thisObj.contiKey = outblock1[outblock1.length - 1].next_key || '';
            }

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }

            console.log(`전체 응답 개수: ${outblock1.length}건`);
            
            console.log('첫 번째 결과 상세:', outblock1[0]);
        });
	}

    //----------------------------------------------------------------------------------------------------------------------------- 정리는 나중에
    /**
     *  더보기 로직
     */
	onNextButtonClick(comp, info, e)
	{

		const thisObj = this;
        const radioGroupValue = this.radioGroupFunc();

        if (radioGroupValue === null) {
            return AToast.show('조회 유형을 선택해주세요.');
        }

        console.log("선택된 값:", radioGroupValue); // '0', '1', '2' 등 출력

        const startDate = this.startDate.getDateString();
        const endDate = this.endDate.getDateString();


        theApp.qm.sendProcessByName('TE1000', this.getContainerId(), null,
        function(queryData) {
            const inblock1 = queryData.getBlockData('InBlock1')[0];
            inblock1.notice_type = radioGroupValue;
            inblock1.start_date = startDate;
            inblock1.end_date = endDate;
            inblock1.next_key = thisObj.contiKey;

            console.log('인블럭1값임: ', inblock1);
            
        },
        function(queryData) {  

            const outblock1 = queryData.getBlockData('OutBlock1');
            console.log('아웃블럭1값임: ', outblock1);

            if (outblock1.length > 0) {
                thisObj.contiKey = outblock1[outblock1.length - 1].next_key || '';
            }
            

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }

            console.log(`전체 응답 개수: ${outblock1.length}건`);
            
            const typeSummary = outblock1.map(item => item.notice_type);
            console.log('받은 데이터들의 타입 리스트:', typeSummary);
            
            console.log('첫 번째 결과 상세:', outblock1[0]);
        });

	}

    /**
     *  추가 로직
     */
	onNoticeAddButtonClick(comp, info, e)
	{

		const thisObj = this;

        const noticeCreateElement = {
            title   : this.noticeTitleText.getText(),
            content : this.noticeContent.getData(),
            type    : this.noticeTypeSelect.getData(),
        };

        if ( !noticeCreateElement ) return AToast.show('모든 항목을 입력해주세요');
    
        theApp.qm.sendProcessByName('TE1011', this.getContainerId(), null,
            function(queryData)
            { // InBlock 설정
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                inblock1.notice_title = noticeCreateElement.title;
                inblock1.notice_content = noticeCreateElement.content;
                inblock1.notice_type = noticeCreateElement.type;

                console.log('인블럭1값임: ', inblock1);
            },
            function(queryData)
        { // OutBlock 처리
        
            const errorData = this.getLastError();
            if (errorData.errFlag == "E") {
                console.log("Error Data:", errorData);
                AToast.show('에러가 발생했습니다.');
                return;
            }
            
            const outblock1 = queryData.getBlockData('OutBlock1');

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }

            if ( outblock1[0].success_status !== 'Y' ) {
                AToast.show('알림 등록에 실패했습니다.');
                return;
            }

            console.log(outblock1[0]);
        });
	}

    /**
     *  조회 로직
     */
	onQueryListSelect(comp, info, e)
	{
        const thisObj = this;
        const targetId = info[0].cells[0].innerText.trim();

        this.noticeIdText.setReadOnly(true);
        
        theApp.qm.sendProcessByName('TE1010', this.getContainerId(), null,
            function(queryData)
            { // InBlock 설정
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                inblock1.notice_id = Number(targetId);

                console.log('쿼리 리스트 셀렉트 인블럭1 값임: ', inblock1);
            },
            function(queryData)
        { // OutBlock 처리
        
            // const errorData = this.getLastError();
            // if (errorData.errFlag == "E") {
            //     console.log("Error Data:", errorData);
            //     AToast.show('에러가 발생했습니다.');
            //     return;
            // }
            
            const outblock1 = queryData.getBlockData('OutBlock1');
            

            const data = outblock1[0];

                thisObj.noticeTypeSelect.selectItemByValue(String(data.notice_type));
                thisObj.noticeContent.setData(data.notice_content);


            console.log('쿼리 리스트 아웃블럭 값임: ', outblock1);
        });
	}

    /**
     *  수정 로직
     */
	onNoticeEditButtonClick(comp, info, e)
	{

		const thisObj = this;

        const noticeCreateElement = {
            title   : this.noticeTitleText.getText(),
            content : this.noticeContent.getData(),
            type    : this.noticeTypeSelect.getData(),
        };

        if ( !noticeCreateElement ) return AToast.show('모든 항목을 입력해주세요');
    
        theApp.qm.sendProcessByName('TE1011', this.getContainerId(), null,
            function(queryData)
            { // InBlock 설정
                const inblock1 = queryData.getBlockData('InBlock1')[0];
                inblock1.notice_title = noticeCreateElement.title;
                inblock1.notice_content = noticeCreateElement.content;
                inblock1.notice_type = noticeCreateElement.type;

                console.log('인블럭1값임: ', inblock1);
            },
            function(queryData)
        { // OutBlock 처리
        
            const errorData = this.getLastError();
            if (errorData.errFlag == "E") {
                console.log("Error Data:", errorData);
                AToast.show('에러가 발생했습니다.');
                return;
            }
            
            const outblock1 = queryData.getBlockData('OutBlock1');

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }

            if ( outblock1[0].success_status !== 'Y' ) {
                AToast.show('알림 등록에 실패했습니다.');
                return;
            }

            console.log(outblock1[0]);
        });

	}
}