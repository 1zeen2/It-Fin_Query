
TE2000 = class TE2000 extends AView
{
	constructor()
	{
		super()

		this.contiKey = '';
        this.userId = '';
        this.startDate = '';
        this.endDate = '';
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.userId = 'admin';
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}
    /**
     *  회원 조회 버튼
     *  엔터키 활용을 위해 조회 버튼만 공통 로직으로 분리.
     */
    doMemberSearch() {
        const thisObj = this;

        const memberTextField = this.memberTextField.getText();

        theApp.qm.sendProcessByName('TE2010', this.getContainerId(), null,
        function(queryData) {
            const inblock1 = queryData.getBlockData('InBlock1')[0];
            inblock1.user_id = thisObj.userId;
            inblock1.search = memberTextField;
            inblock1.next_key = '';


            console.log('인블럭1값임: ', inblock1);
            
        },
        function(queryData) {  

            const outblock1 = queryData.getBlockData('OutBlock1');
            console.log('아웃블럭1값임: ', outblock1);

            thisObj.memberList.removeAll();

            thisObj.contiKey = outblock1[outblock1.length - 1].next_key || '';

            console.log(`전체 응답 개수: ${outblock1.length}건`);
            
            console.log('첫 번째 결과 상세:', outblock1[0]);

        });
    }

	onMemberInquiryButtonClick(comp, info, e)
	{

        this.doMemberSearch();

	}

    onMemberTextFieldKeyup(comp, info, e)
	{

		if (e.keyCode === 13) {
            this.doMemberSearch();
        }

	}

	onMemberNextButtonClick(comp, info, e)
	{

		const thisObj = this;

        const memberTextField = this.memberTextField.getText();

        theApp.qm.sendProcessByName('TE2010', this.getContainerId(), null,
        function(queryData) {
            const inblock1 = queryData.getBlockData('InBlock1')[0];
            inblock1.user_id = thisObj.userId;
            inblock1.search = memberTextField;
            inblock1.next_key = thisObj.contiKey;


            console.log('인블럭1값임: ', inblock1);
            
        },
        function(queryData) {  

            const outblock1 = queryData.getBlockData('OutBlock1');
            console.log('아웃블럭1값임: ', outblock1);

            if (outblock1.length > 0) {
                thisObj.contiKey = outblock1[outblock1.length - 1].next_key || '';
            }
            

            if ( !outblock1 || outblock1.length <= 0 ) {
                AToast.show('조회된 데이터가 없습니다.');
                return;
            }

            console.log(`전체 응답 개수: ${outblock1.length}건`);
            
            const typeSummary = outblock1.map(item => item.notice_type);
            console.log('받은 데이터들의 타입 리스트:', typeSummary);
            
        });

	}

    onMemberListSelect(comp, info, e) {

        const redRow = info;
        const $row = $(info);

        this.currentAcntCd = $row.find('td').eq(3).text().trim();
        console.log('계좌 값 넘어오는지 확인: ', this.currentAcntCd);

        const tabView = this.TradeListTabView;
        tabView.getContainer().setData({
            parent: this // 부모 인스턴스 자체를 전달, 필요한 데이터 뽑아서 사용.
        });
    }

	
    // onTradeListTabClick(comp, info, e)
	// {

	// 	const tabId = comp.getComponentId();

    //     if (this.tradeListTabView && tabId) {
    //         this.tradeListTabView.selectTabById(`${tabId}`);
    //     }

	// }
	
}

